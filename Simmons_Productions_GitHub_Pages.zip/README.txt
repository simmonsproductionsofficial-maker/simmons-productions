SIMMONS PRODUCTIONS WEBSITE

Open index.html in a web browser to preview the website.
Keep the assets folder next to index.html so the images load correctly.

The design uses a photo-led homepage, featured category gallery, about section,
services, and contact links. It is inspired by the category-led photography
portfolio structure of DTV Productions, while keeping Simmons Productions'
own branding and content.

Before publishing, replace the concept images in assets/ with original photos
you have permission to publish. Update the site copy as your portfolio grows.
A parent or guardian should supervise customer inquiries, scheduling,
agreements, and payment arrangements.
